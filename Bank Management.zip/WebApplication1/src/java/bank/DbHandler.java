package bank;

import bank.Customer;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.logging.Level;
import java.util.logging.Logger;
import java.sql.Statement;

import java.sql.ResultSet;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;

public class DbHandler {
	private Connection con;
    private String DBURL = "jdbc:mysql://localhost/bank";
    private String DBUser = "root";
    private String DBPassword = "1234";

    public DbHandler()
    {
        try { 
            connection();
        } catch (ClassNotFoundException ex) {
            Logger.getLogger(DbHandler.class.getName()).log(Level.SEVERE, null, ex);
        } catch (SQLException ex) {
            Logger.getLogger(DbHandler.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
    private void connection() throws ClassNotFoundException,SQLException
    { 
            Class.forName("com.mysql.jdbc.Driver");
            con=(Connection) DriverManager.getConnection(DBURL, DBUser, DBPassword);
    }
    public boolean customerLogin(String username,String password)
    {
       
    try{
    String query = "select username from customer where username ='" + username + "'  and password='" + password + "'";
    Statement stmt = null;
    stmt = (Statement) con.createStatement();
    ResultSet rs=stmt.executeQuery(query);
    if (rs.next()) {
        //System.out.println("Success");
        return true;
    }
    //System.out.println("User not exist with this email");
    return false;
    }
    catch(Exception e)
    {
        System.err.println(e);
        return false;
    }
    }
    public boolean adminLogin(String username,String password)
    {
       
    try{
    String query = "select * from admin where username ='" + username + "'  and password='" + password + "'";
    Statement stmt = null;
    stmt = (Statement) con.createStatement();
    ResultSet rs=stmt.executeQuery(query);
    if (rs.next()) {
        //System.out.println("Success");
        return true;
    }
    //System.out.println("User not exist with this email");
    return false;
    }
    catch(Exception e)
    {
        System.err.println(e);
        return false;
    }
    }
    public boolean customerSignup(Customer c) throws ClassNotFoundException,SQLException
    {
    	PreparedStatement prst=null;
        String query="insert into customer( username,phone,address,accountType,password,balance) values(?,?,?,?,?,?);";
        try{
        prst=(PreparedStatement) con.prepareStatement(query);
        

        prst.setString(1,c.getUsername());
        prst.setString(2,c.getPhone());
        prst.setString(3,c.getAddress());
        prst.setString(4,c.getAccountType());
        prst.setString(5,c.getPassword());
        prst.setInt(6,c.getBalance());
        
        prst.execute();
        return true;
        }catch(Exception e)
        {
            e.printStackTrace();
            return false;
        }
    	
    }
    public boolean transaction(int senderAccount,int receiverAccount,int amount,String date)
    {
    	PreparedStatement prst=null;
        String query="insert into transaction values(?,?,?,?);";
        try{
        prst=(PreparedStatement) con.prepareStatement(query);
        

        prst.setInt(1,senderAccount);
        prst.setInt(2,receiverAccount);
        prst.setInt(3,amount);
        prst.setString(4,date);
        prst.execute();
        return true;
        }catch(Exception e)
        {
            e.printStackTrace();
            return false;
        }
    	
    }
    
    public boolean updateBalance(int accountNumber,int balance)
    {
    	PreparedStatement prst=null;
        String query="update customer set balance=? where accountNumber=?";
        try{
        prst=(PreparedStatement) con.prepareStatement(query);
       

        prst.setInt(1,balance);
        prst.setInt(2, accountNumber);
       
        prst.executeUpdate();
        return true;
        }catch(Exception e)
        {
            e.printStackTrace();
        	return false;
            
        }
	
    }
     public boolean deleteCustomer(int accountNumber)
    {
    	PreparedStatement prst=null;
        String query="delete from customer where accountNumber=?";
        try{
        prst=(PreparedStatement) con.prepareStatement(query);
      
        prst.setInt(1, accountNumber);
       
        int rows=prst.executeUpdate();
        if (rows>0)
            return true;
        else
            return false;
        }catch(Exception e)
        {
            e.printStackTrace();
        	return false;
            
        }
	
    }
    public int maxAccountNumber()
    {
    	try{
            String query = "select max(accountNumber) FROM customer";
            Statement stmt = null;
            stmt = (Statement) con.createStatement();
            ResultSet rs=(ResultSet) stmt.executeQuery(query);
            if (rs.next()) {

                return rs.getInt(1);
            }
            
            return 0;
            }
            catch(Exception e)
            {
                System.err.println(e);
                return 0;
            }

    }
    public boolean isAccountExist(int accountNumber)
    {
    	try{
            String query = "select * FROM customer where accountNumber ='" + accountNumber + "'";
            Statement stmt = null;
            stmt = (Statement) con.createStatement();
            ResultSet rs=(ResultSet) stmt.executeQuery(query);
            if (rs.next()) {

                return true;
            }
            return false;
            }
            catch(Exception e)
            {
                System.err.println(e);
                return false;
            }

    }
    
    public boolean isUsernameExist(String username)
    {
    	try{
            String query = "select * FROM customer where username ='" + username + "'";
            Statement stmt = null;
            stmt = (Statement) con.createStatement();
            ResultSet rs=(ResultSet) stmt.executeQuery(query);
            if (rs.next()) {

                return true;
            }
            return false;
            }
            catch(Exception e)
            {
                System.err.println(e);
                return false;
            }

    }
    public Customer getCustomerFromAccountNumber(int account)
    {
        Customer c=null;
        try{
            String query = "select * FROM customer where accountNumber ='" + account + "'";
            Statement stmt = null;
            stmt = (Statement) con.createStatement();
            ResultSet rs=(ResultSet) stmt.executeQuery(query);
            
            if (rs.next()) {
                String username=rs.getString(1);
                String phone=rs.getString(2);
                String address=rs.getString(3);
                int accountNumber=rs.getInt(4);
                String accountType=rs.getString(5);
                String password=rs.getString(6);
                int balance=rs.getInt(7);
                c=new Customer(username,phone,address,accountNumber,accountType,password,balance);


                
            }
            return c;
            }
            catch(Exception e)
            {
                System.err.println(e);
                return c;
            }
        
    }
    public Customer getCustomerData(String name)
    {
        Customer c=null;
        try{
            String query = "select * FROM customer where username ='" + name + "'";
            Statement stmt = null;
            stmt = (Statement) con.createStatement();
            ResultSet rs=(ResultSet) stmt.executeQuery(query);
            
            if (rs.next()) {
                String username=rs.getString(1);
                String phone=rs.getString(2);
                String address=rs.getString(3);
                int accountNumber=rs.getInt(4);
                String accountType=rs.getString(5);
                String password=rs.getString(6);
                int balance=rs.getInt(7);
                c=new Customer(username,phone,address,accountNumber,accountType,password,balance);


                
            }
            return c;
            }
            catch(Exception e)
            {
                System.err.println(e);
                return c;
            }
    }
    public ArrayList<Customer> getAllCustomers() throws SQLException
    {
        ArrayList<Customer> list=new ArrayList<Customer>();
        java.sql.Statement st;
     String query="select * FROM customer";
     st=con.createStatement();
     ResultSet rs=st.executeQuery(query);
     while(rs.next()){
         String username=rs.getString(1);
         String phone=rs.getString(2);
         String address=rs.getString(3);
         int accountNumber=rs.getInt(4);
         String accountType=rs.getString(5);
         String password=rs.getString(6);
         int balance=rs.getInt(7);
         Customer c=new Customer(username,phone,address,accountNumber,accountType,password,balance);
         list.add(c);
     }
     return list;
    }
	public static void main(String []args) throws ClassNotFoundException
	{
		
		DbHandler db=new DbHandler();
		//System.out.println(db.insert("admin", "admin"));
		//db.customerSignup("haris","123", "saving", "1213231",0);
		//System.out.println(db.transaction("123", "receiverAccount", 100, "23-09-2020"));
		//System.out.println(db.updateBalance("1213231", 100));
		//System.out.println(db.isAccountExist("121321"));
		//System.out.println(db.isUsernameExist("haris"));
		//System.out.println(db.maxAccountNumber());
               // System.out.println(db.customerLogin("haris", "124"));
                //Customer c=db.getCustomerData("haris");
               // Customer c=db.getCustomerFromAccountNumber(2);
                //System.out.println(c.getAccountType());
                //DateFormat df = new SimpleDateFormat("dd/MM/yy HH:mm:ss");
                

                //Date dateobj= new Date();
                //System.out.println(df.format(dateobj));
                //db.transaction(1, 2, 100, df.format(dateobj));
                System.out.println(db.deleteCustomer(3));

	}
}