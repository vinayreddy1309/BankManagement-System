package bank;

public class Customer {
private String username;
private String phone;
private String address;
private int accountNumber;
private String accountType;
private String password;
private int balance;
private String email;
    public Customer(String username, String phone, String address, int accountNumber, String accountType, String password, int balance) {
        this.username = username;
        this.phone = phone;
        this.address = address;
        this.accountNumber = accountNumber;
        this.accountType = accountType;
        this.password = password;
        this.balance = balance;
        
    }



public Customer(String username, String phone, String address, String accountType, String password,
		int balance) {
	super();
	this.username = username;
	this.phone = phone;
	this.address = address;
	this.accountType = accountType;
	this.password = password;
	this.balance = balance;
}
public String getUsername() {
	return username;
}
public void setUsername(String username) {
	this.username = username;
}
public String getPhone() {
	return phone;
}
public void setPhone(String phone) {
	this.phone = phone;
}
public String getAddress() {
	return address;
}
public void setAddress(String address) {
	this.address = address;
}
public int getAccountNumber() {
	return accountNumber;
}
public void setAccountNumber(int accountNumber) {
	this.accountNumber = accountNumber;
}
public String getAccountType() {
	return accountType;
}
public void setAccountType(String accountType) {
	this.accountType = accountType;
}
public String getPassword() {
	return password;
}
public void setPassword(String password) {
	this.password = password;
}
public int getBalance() {
	return balance;
}
public void setBalance(int balance) {
	this.balance = balance;
}



}
